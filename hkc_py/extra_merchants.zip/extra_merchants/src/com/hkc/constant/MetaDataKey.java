package com.hkc.constant;

public interface MetaDataKey {

	//渠道名称
	public static final String HKC_CHANNEL = "HKC_CHANNEL";
	
	// 爱火商盟的AppKey
	public static final String HKC_APP_KEY = "HKC_AH_APP_KEY";
	
	//友盟统计的appkey
	public static final String HKC_UM_APP_KEY = "HKC_UM_APP_KEY";
}
