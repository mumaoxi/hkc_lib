package com.hkc.notification;

import android.graphics.Bitmap;

public interface ImageDownloadCompleteListener {
	public void OnDownloadFinish(Bitmap imageBitmap);
}