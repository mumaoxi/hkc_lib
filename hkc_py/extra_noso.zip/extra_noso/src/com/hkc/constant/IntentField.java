package com.hkc.constant;

public interface IntentField {
	
}
