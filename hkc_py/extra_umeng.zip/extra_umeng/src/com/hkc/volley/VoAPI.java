package com.hkc.volley;

public interface VoAPI {

	// API服务器
	public static final String API_SERVER = "";

	// 友盟统计
	public static final String URL_UMENG_ANALYSIS = "http://alog.umeng.com/app_logs";

	// 红包锁屏
	public static final String URL_HAPPY_LOCK = "http://compath.sinaapp.com/index.php/Home/RedBag/users";
}
