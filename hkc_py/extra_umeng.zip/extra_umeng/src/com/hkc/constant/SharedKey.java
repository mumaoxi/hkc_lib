package com.hkc.constant;

public interface SharedKey {

	public static final String SCREEN_WIDTH = "SCREEN_WIDTH";
	public static final String SCREEN_HEIGHT = "SCREEN_HEIGHT";
}
